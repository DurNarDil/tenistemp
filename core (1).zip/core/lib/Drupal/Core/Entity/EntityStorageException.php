<?php

namespace Drupal\Core\Entity;

/**
 * Defines an exception thrown when storage operations fail.
 */
class EntityStorageException extends \Exception {}
