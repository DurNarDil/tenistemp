<?php

namespace Drupal\Core\Entity\Exception;

/**
 * Defines an exception class for undefined link templates.
 */
class UndefinedLinkTemplateException extends \RuntimeException {

}
